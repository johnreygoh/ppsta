<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IF Demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<div class="box">

    <h1>IF DEMO</h1>

    <!-- 
        scenario:

    inputs: name, department, daysworked
    salary per day: MIS 80000, HR 70000, Accouting 60000
    deduction: 1000 (if days <10), 3000 (if days <10)

    -->

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        name <input type="text" name="txt_name"><br />
        department 
            <select name="cbo_dept">
                <option value="MIS">MIS</option>
                <option value="HR">HR</option>
                <option value="Accounting">Accounting</option>
            </select><br />
        days worked <input type="number" name="txt_days">
        <br /><br />
        <input type="submit" name="btnsubmit" value="submit">
    </form>

    <hr />

    <div>
    <?php
        if(isset($_POST["btnsubmit"])){
            $name = $_POST["txt_name"];
            $dept = $_POST["cbo_dept"];
            $days = $_POST["txt_days"];

            $sal = 0;
            if($dept=="MIS"){ 
                $sal = 1000; 
            }elseif($dept=="HR"){ 
                $sal = 700; 
            }elseif($dept=="Accounting"){
                 $sal = 800; 
            }

            $ded = 0;
            if($days<=10){ $ded = 1000; }
            else{ $ded = 3000; }

            $netpay = ($sal*$days)-$ded;
            
            echo "Good day $name!<br />You will receive PHP$netpay";

        }

    ?>

    </div>





</div>





    
</body>
</html>