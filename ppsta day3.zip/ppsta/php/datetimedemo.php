<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>datetime demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box">

<?php 
// date_default_timezone_set("Asia/Manila");
echo date("M F m")."<br />"; //Sep September 09
echo date("D l d")."<br />"; //Wed Wednesday 20
echo date("Y y")."<br />"; //2023 
echo date("h H")."<br />"; //1-12 0-23
echo date("h:i:s a")."<br />"; //8:57:22 am
echo date("F d, Y h:i a (l)");
// change timezone in PHP configuration php.ini



?>

</div>



    
</body>
</html>