<?php
use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return function (RouteBuilder $routes): void {
    $routes->setRouteClass(DashedRoute::class);

    $routes->scope('/', function (RouteBuilder $builder): void {
        $builder->connect('/', ['controller' => 'Pages', 'action' => 'display', 'home']);
        
        // SamplesController
        // localhost/ppstacake4/s/p1
        $builder->connect('/s', ['controller' => 'Samples', 'action' => 'index']);
        $builder->connect('/s/p1', ['controller' => 'Samples', 'action' => 'page1']);
        $builder->connect('/s/p2', ['controller' => 'Samples', 'action' => 'page2']);
        $builder->connect('/s/name/:fname/:lname', 
                ['controller' => 'Samples', 'action' => 'name'],
                ['pass' => ['fname','lname']]
            );
        
     
        // DemosController
        // localhost/ppstacake4/d/p1
        $builder->connect('/d',['controller'=>'Demos','action'=>'index']);
        $builder->connect('/d/page1',['controller'=>'Demos','action'=>'page1']);
        $builder->connect('/d/maintenance',['controller'=>'Demos','action'=>'maintenance']);
        // $builder->redirect('/d/p1','https://google.com');
        
        // EmployeesController
        // localhost/ppstacake4/employees
        $builder->connect('/employees',['controller'=>'Employees','action'=>'index']);
        $builder->connect('/employees/add',['controller'=>'Employees','action'=>'add']);
        $builder->connect('/employees/edit',['controller'=>'Employees','action'=>'edit']);
        $builder->connect('/employees/delete',['controller'=>'Employees','action'=>'delete']);


        $builder->connect('/pages/*', 'Pages::display');
        $builder->fallbacks();
    });

};
