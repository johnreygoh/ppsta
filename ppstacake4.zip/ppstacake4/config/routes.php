<?php
use Cake\Routing\Route\DashedRoute;
use Cake\Routing\RouteBuilder;

return function (RouteBuilder $routes): void {
    $routes->setRouteClass(DashedRoute::class);

    $routes->scope('/', function (RouteBuilder $builder): void {
        $builder->connect('/', ['controller' => 'Pages', 'action' => 'display', 'home']);
        
        // localhost/ppstacake4/samples/p1
        $builder->connect('/s', ['controller' => 'Samples', 'action' => 'index']);
        $builder->connect('/s/p1', ['controller' => 'Samples', 'action' => 'page1']);
        $builder->connect('/s/p2', ['controller' => 'Samples', 'action' => 'page2']);
        $builder->connect('/s/name/:fname/:lname', 
                ['controller' => 'Samples', 'action' => 'name'],
                ['pass' => ['fname','lname']]
            );
        
        
        $builder->connect('/pages/*', 'Pages::display');
        $builder->fallbacks();
    });

};
