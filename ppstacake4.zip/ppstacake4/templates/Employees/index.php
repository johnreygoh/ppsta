<a href="employees/add">Add Employee Account</a>

<table>
    <tr>
        <th>Employee ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Department</th>
        <th>Position</th>
        <th>Salary</th>
        <th>Edit</th>
        <th>Delete</th>

    </tr>

    <?php 
    foreach($results as $row):
        echo "<tr>";
        echo "<td>$row->empid</td>";
        echo "<td>$row->firstname</td>";
        echo "<td>$row->lastname</td>";
        echo "<td>$row->department</td>";
        echo "<td>$row->position</td>";
        echo "<td>$row->salary</td>";
        echo "<td><a href='"
            . $this->Url->build(["controller"=>"Employees","action"=>"edit",$row->empid]) 
            . "'>Edit</a></td>";
        echo "<td><a href='"
            . $this->Url->build(["controller"=>"Employees","action"=>"delete",$row->empid]) 
            . "'>Delete</a></td>";
        echo "</tr>";
    endforeach;
    ?>
</table>



