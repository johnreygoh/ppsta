<?php 

echo $this->Form->create(NULL,array('url'=>'/employees/edit/'.$empid));
echo $this->Form->control('firstname',['value'=>$firstname]);
echo $this->Form->control('lastname',['value'=>$lastname]);
echo $this->Form->control('department',['value'=>$department]);
echo $this->Form->control('position',['value'=>$position]);
echo $this->Form->control('salary',['value'=>$salary]);
echo $this->Form->button('Submit');
echo $this->Form->end();

?>