<?php 
// echo $this->Form->create(NULL,array('url'=>'/employees/add'));
// echo $this->Form->control('firstname');
// echo $this->Form->control('lastname');
// echo $this->Form->control('department');
// echo $this->Form->control('position');
// echo $this->Form->control('salary');
// echo $this->Form->button('Submit');
// echo $this->Form->end();
?>

<form method="post" action="/ppstacake4/employees/add"> 

<input type="hidden" name="_csrfToken" value=<?php echo json_encode($this->request->getAttribute('csrfToken')); ?>>

<label for="firstname">First Name</label>
<input type="text" name="firstname"> <br />

<label for="lastname">Last Name</label>
<input type="text" name="lastname"> <br />

<label for="department">Department</label>
<select name="department">
    <option value="mis">MIS</option>
    <option value="hr">HR</option>
    <option value="accounting">ACCOUTING</option>
</select>
<br /><br />

<label for="position">Position</label>
<input type="text" name="position"> <br />

<label for="salary">Salary</label>
<input type="number" name="salary"> <br />



<input type="Submit" name="Submit" value="Submit">
</form>