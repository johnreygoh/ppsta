<h1>This is the Name Page</h1>

<?php
echo "First name: " . $fn . "<br />";
echo "Last name: " . $ln . "<br />";
?>