<?php
declare(strict_types=1);

namespace App\Test\TestCase\Controller;

use App\Controller\SampletwoController;
use Cake\TestSuite\IntegrationTestTrait;
use Cake\TestSuite\TestCase;

/**
 * App\Controller\SampletwoController Test Case
 *
 * @uses \App\Controller\SampletwoController
 */
class SampletwoControllerTest extends TestCase
{
    use IntegrationTestTrait;
}
