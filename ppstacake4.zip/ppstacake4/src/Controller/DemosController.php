<?php
declare(strict_types=1);
namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;

class DemosController extends AppController{

    public function index(){

    }

    public function page1(){
        // echo "redirected from page 1....";
        // $this->setAction('maintenance');

    }

    public function maintenance(){

    }



}


