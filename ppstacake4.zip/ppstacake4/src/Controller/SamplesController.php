<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\Core\Configure;
use Cake\Http\Exception\ForbiddenException;
use Cake\Http\Exception\NotFoundException;
use Cake\Http\Response;
use Cake\View\Exception\MissingTemplateException;

class SamplesController extends AppController{

    public function index(){

    }

    public function page1(){

    }

    public function page2(){

    }

    public function name($fname,$lname){
        $this->set('fn',$fname);
        $this->set('ln',$lname);
    }



}

