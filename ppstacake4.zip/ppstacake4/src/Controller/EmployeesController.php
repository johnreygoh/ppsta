<?php 
declare(strict_types=1);
namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;

class EmployeesController extends AppController{

    public function index(){
        $employees = TableRegistry::get('employees');
        $query = $employees->find();
        $this->set('results',$query);
    }

    public function add(){
        if($this->request->is('post')){
            $firstname = $this->request->getData('firstname');
            $lastname = $this->request->getData('lastname');
            $department = $this->request->getData('department');
            $position = $this->request->getData('position');
            $salary = $this->request->getData('salary');

            // variable to rep employees table
            $employees_table = TableRegistry::get('employees');

            // create an employee object
            $employees = $employees_table->newEntity($this->request->getData());
            $employees->firstname = $firstname;
            $employees->lastname = $lastname;
            $employees->department = $department;
            $employees->position = $position;
            $employees->salary = $salary;

            // set employees object as employee new record
            $this->set('employees',$employees);

            // save employees object to database
            if($employees_table->save($employees)){
                echo "New Employee Record added.";
            }

        }
    }

    public function edit($empid){

        if($this->request->is('post')){
            // edit form -> submit update
            $firstname = $this->request->getData('firstname');
            $lastname = $this->request->getData('lastname');
            $department = $this->request->getData('department');
            $position = $this->request->getData('position');
            $salary = $this->request->getData('salary');

            $employees_table = TableRegistry::get('employees');
            $employees = $employees_table->get($empid);

            $employees->firstname = $firstname;
            $employees->lastname = $lastname;
            $employees->department = $department;
            $employees->position = $position;
            $employees->salary = $salary;

            if($employees_table->save($employees)){
                echo "Record Updated!";
                $this->setAction('index');
            }
        }else{
            // if coming from link
            // load values into form
            $employees_table = TableRegistry::get('employees')->find();
            $employees = $employees_table->where(['empid'=>$empid])->first();
            $this->set('empid',$employees->empid);
            $this->set('firstname',$employees->firstname);
            $this->set('lastname',$employees->lastname);
            $this->set('department',$employees->department);
            $this->set('position',$employees->position);
            $this->set('salary',$employees->salary);
        }

    }

    public function delete($empid){

        $employees_table = TableRegistry::get('employees');
        $employees = $employees_table->get($empid);

        if($employees_table->delete($employees)){
            echo "Record deleted successfully";
        }

        // ok or not
        $this->setAction('index');
    }
    

}

