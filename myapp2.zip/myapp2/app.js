$(document).ready(function(){

    // endpoint url
    const apiUrl = 'http://localhost/myapi2/posts';

    // get and display records
    function getPosts(){
        $.ajax({
            url: apiUrl + '.json',
            method: 'GET',
            success: function(response){
                $('#posts').empty();
                response.posts.forEach(post=>{
                    // use backquote `
                    $('#posts').append(`
                    <div>
                        <p><strong>${post.title}</strong>: ${post.body}</p>
                        <button onclick="editPost(${post.id},'${post.title}','${post.body}')">EDIT</button>
                        <button onclick="deletePost(${post.id})">DELETE</button>
                    </div>
                    `);
                })
            }
        })
    }

    
    // function to show hidden form to edit-delete
    window.editPost = function(id,title,body){
        $('#updateId').val(id);
        $('#updateTitle').val(title);
        $('#updateBody').val(body);
        $('#updatePostSection').show();
    }; 

    // function to delete a post
    window.deletePost = function(id){
        if(confirm('Are you sure to delete this post?')){
            $.ajax({
                url: apiUrl + '/delete/' + id + '.json',
                method: 'DELETE',
                success: function(){
                    alert('Post Deleted');
                    getPosts();
                }
            });
        }
    }

    // create post
    $('#createPostForm').submit(function(e){
        e.preventDefault();

        const postData = {
            title: $('#title').val(),
            body: $('#body').val()
        };

        $.ajax({
            url: apiUrl + "/add.json",
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(postData),
            success: function(){
                alert('Post Created');
                $('#title').val('');
                $('#body').val('');
                getPosts();
            }
        });

    });

    // update post
    $('#updatePostForm').submit(function(e){
        e.preventDefault();

        const postData = {
            title: $('#updateTitle').val(),
            body: $('#updateBody').val(),
        }

        $.ajax({
            url: apiUrl + '/edit/' + $('#updateId').val() + '.json',
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(postData),
            success: function(){
                alert('Post Updated');
                $('#updatePostSection').hide();
                getPosts();
            }
        });
    });


    // call getPosts initially
    getPosts();

});