<?php 
// get values submitted from the form (formsubmission.php)

// global variables 
$f = $_POST["txt_fn"];
$l = $_POST["txt_ln"];
$d = $_POST["cbo_dept"];
$s = $_POST["rad_sched"];

echo "Good day $f $l! <br />You are requesting a $s in $d.<br /><br />";
echo "<a href='formsubmission.php'>back to form</a>";

?>