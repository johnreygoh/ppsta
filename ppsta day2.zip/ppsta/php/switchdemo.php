<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Switch demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("navbar.php"); ?>

<div class="box">

<h1>Switch Demo</h1>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

name <input type="text" name="txt_name"> <br />
birth year 
    <select name="cbo_byear">
        <?php
            $curryear = date('Y');
            for($year=$curryear;$year>=1940;$year=$year-1){
                echo "<option value=$year>$year</option>";
            }
        ?>
    </select>
<br />
gender 
<input type="radio" name="rad_gender" value="male">male
<input type="radio" name="rad_gender" value="female">female
<br /><br />
<input type="submit" name="btnsubmit" value="submit">
</form>

<div>

<?php 

if(isset($_POST["btnsubmit"])){
    $n = $_POST["txt_name"];
    $by = $_POST["cbo_byear"];
    $age = date('Y') - $by;
    $g = $_POST["rad_gender"];
    $t = "";

        if($age >= 18){
            
            switch($g){

                case "male": $t = "Mr.";break;
                
                case "female":
                    $t = "Miss";
                    break;

                default:
                    $t = "";
                    break;

            }//closing switch
        }//closing if
        
        echo "$t <b>$n</b> born: $by , age now: $age";

}//closing isset

?>


</div>






</div>






    
</body>
</html>