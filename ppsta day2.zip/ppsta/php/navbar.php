

<!-- navbar starts -->
<div class="navbar navbar-inverse">
        <div class="container-fluid">
          <div class="navbar-header">
            <a class="navbar-brand" href="#">PHP DEMO</a>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="index.php">Home</a></li>
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#">Demo
              <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="sample1.php">sample1</a></li>
                <li><a href="sample2.php">sample2</a></li>
                <li><a href="formsubmission.php">form submission</a></li>
                <li><a href="ifdemo.php">if condition</a></li>
                <li><a href="switchdemo.php">switch demo</a></li>
                <li><a href="stringfunctions.php">string functions</a></li>
                <li><a href="datetimedemo.php">date and time demo</a></li>
                <li><a href="filehandling.php">file handling</a></li>
                <li><a href="fileupload.php">file upload</a></li>
              </ul>
            </li>
            <li><a href="#">Page 2</a></li>
            <li><a href="#">Page 3</a></li>
          </ul>
        </div>
      </div>
<!-- navbar stops -->