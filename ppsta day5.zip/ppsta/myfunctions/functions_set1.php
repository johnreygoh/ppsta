<?php

function clean_input($input){
    $clean = str_replace('/','',stripslashes(htmlspecialchars(trim($input))));
    return $clean;

    // return str_replace('/','',stripslashes(htmlspecialchars(trim($input))));
}

function getnetpay($grosspay,$deductions){
    return $grosspay-$deductions;
}

$companyname="PPSTA";

?>