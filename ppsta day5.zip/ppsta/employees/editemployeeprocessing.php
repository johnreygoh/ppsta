<?php
if(isset($_POST['btn_submit'])){

    $id = $_POST['txt_id'];
    $fn = $_POST['txt_fn'];
    $ln = $_POST['txt_ln'];
    $de = $_POST['txt_de'];
    $po = $_POST['txt_po'];
    $sa = $_POST['txt_sa'];
    
    require('connections/connection1.php');
    // $sql = "update employees set 
    //         firstname='$fn', 
    //         lastname='$ln', 
    //         department='$de', 
    //         position='$po', 
    //         salary=$sa 
    //         where empid=$id           
    //         ";

    require('connections/functions.php');
    $sql = updaterec($id,$fn,$ln,$de,$po,$sa);

    mysqli_query($con,$sql) or die(mysqli_error($con));
    // actions
    mysqli_close($con);
    header("LOCATION:showemployees.php");
}
?>