<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box">

<?php 
if(isset($_POST['btn_submit'])){
    //process login
    $u = htmlspecialchars(trim($_POST['txt_user']));
    $p = htmlspecialchars(trim($_POST['txt_pass']));

    require('connections/connection1.php');
    $sql = "select * from authentication where username='$u' and password='$p'";
    $result = mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        //correct
        $_SESSION["user"]=$u;
        mysqli_close($con);
        header("LOCATION:showemployees.php");
    }else{
        //incorrect
        session_destroy();
        mysqli_close($con);
        header("LOCATION:accessdenied.php");
    } 

}else{
    header("LOCATION:index.php");
}

?>



</div>

    
</body>
</html>