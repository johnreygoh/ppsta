<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee-Home</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box row">
<div class="col-md-4"> 
    <form method="post" action="processlogin.php">

    <label for="txt_user">User Name</label>
    <input type="text" class="form-control" name="txt_user" required><br />

    <label for="txt_pass">Password</label>
    <input type="password" class="form-control" name="txt_pass" required><br /><br />

    <input type="submit" class="btn btn-primary" name="btn_submit" value="log in">

    </form>
</div>
</div>

    
</body>
</html>