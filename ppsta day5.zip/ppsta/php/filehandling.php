<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Handling</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<div class="box">

<h1>Product Registration</h1>

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
Product Name <input type="text" name="txt_name"><br />
Description <input type="text" name="txt_desc"><br />
Price <input type="text" name="txt_price"><br />
<input type="submit" name="btn_submit" value="register">
</form>

<?php 
if(isset($_POST['btn_submit'])){

    $n = $_POST['txt_name'];
    $d = $_POST['txt_desc'];
    $p = $_POST['txt_price'];

    // create a txt file and write to it
    //$file = "../logs/products.txt" or die("file not found");
    $file = "../logs/products.csv" or die("file not found");
    
    // shared file over network
    //$file = "\\\\servername\\shared\\log.txt"
    //live url
    //$file = "http://ppsta.com/audits/log.txt"
    //$file = "ftp://ppsta.org/creds/user.txt?user=jhef&pass=122456"

    // modes: w(write),a(append),r(read-only)
    $fh = fopen($file,'a') or die("could not open file");
    //fwrite($fh,date('Y-m-d h:i a')."\t$n \t$d \t$p \n") or die("error writing to file");
    fwrite($fh,date('Y-m-d h:i a').",$n,$d,$p \n") or die("error writing to file");
    
    fclose($fh);

    echo "<a href='filehandling.php'>add another product</a>";
    echo "<br /><br />New product registered($n)";
    
    // open, read and display content
    echo "<hr />Products Registered<br /><br />";
    $fh2 = fopen($file,'r') or die("file not found");
    $data = fread($fh2,filesize($file)) or die("error reading file");
    fclose($fh2);

    echo "<textarea cols='100' rows='10'>$data</textarea>";
}
?>








</div>

<br /><br /><br /><br /><br />    
</body>
</html>