<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<div class="box">

<?php if(!isset($_SESSION["user"])){ ?>

please login to view all pages<br />
<form method="post" action="processlogin.php">
username <input type="text" name="txt_user"><br />
password <input type="text" name="txt_pass"><br />
<input type="submit" name="btn_submit" value="log in">
</form>

<?php 
}else{
    echo "Welcome ".$_SESSION["user"]."<br />";
    echo "<a href='logout.php'>Logout</a>";
} 
?>




</div>


    
</body>
</html>