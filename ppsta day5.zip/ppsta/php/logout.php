<?php
session_start();

// ! means NOT
// if NOT isset
if(isset($_SESSION["user"])){
    // unset($_SESSION["user"]);
    session_destroy();
    header("LOCATION:index.php");
    
}else{
    header("LOCATION:accessdenied.php");
}
?>