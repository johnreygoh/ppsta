<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Posts Controller
 *
 * @property \App\Model\Table\PostsTable $Posts
 * @method \App\Model\Entity\Post[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PostsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        //GET
        $this->request->allowMethod('get');
        $posts = $this->Posts->find('all');
        $this->set([
            'posts' => $posts,
            'status' => 'success',
            '_serialize' => ['posts','status']
        ]);
    }

    /**
     * View method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $post = $this->Posts->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('post'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->request->allowMethod(['post','put']);
        // new empty instance, did not collect input yet
        $post = $this->Posts->newEmptyEntity(); 
        // collect user input
        $post = $this->Posts->patchEntity($post,$this->request->getData());

        // add or save record
        if($this->Posts->save($post)){
            $message = 'Saved';
        }else{
            $message = 'Error';
        }

        $this->set([
            'message' => $message,
            'post' => $post,
            '_serialize' => ['message','post']
        ]);
    }

    /**
     * Edit method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->request->allowMethod(['patch','post','put']);
        // get the existing rec using id, did not collect input yet
        $post = $this->Posts->get($id); 
        // collect user input
        $post = $this->Posts->patchEntity($post,$this->request->getData());

        // add or save record
        if($this->Posts->save($post)){
            $message = 'Saved';
        }else{
            $message = 'Error';
        }

        $this->set([
            'message' => $message,
            'post' => $post,
            '_serialize' => ['message','post']
        ]);
    }

    /**
     * Delete method
     *
     * @param string|null $id Post id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
      
        $this->request->allowMethod(['post','delete']);
        // get existing record, did not collect input yet
        $post = $this->Posts->get($id); 
        
        // delete record
        if($this->Posts->delete($post)){
            $message = 'Deleted';
        }else{
            $message = 'Error';
        }

        $this->set([
            'message' => $message,
            '_serialize' => ['message']
        ]);
    }
}
