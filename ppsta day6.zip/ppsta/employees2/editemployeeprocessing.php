<?php
if(isset($_POST['btn_submit'])){

    $id = $_POST['txt_id'];
    $fn = $_POST['txt_fn'];
    $ln = $_POST['txt_ln'];
    $de = $_POST['txt_de'];
    $po = $_POST['txt_po'];
    $sa = $_POST['txt_sa'];
    
    require('connections/connection2.php');

    $stmt = $mysqli->prepare("CALL editemployee(?,?,?,?,?,?)");
    $stmt->bind_param("ssssss",$id,$fn,$ln,$de,$po,$sa);
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
    header("LOCATION:showemployees.php");
}
?>