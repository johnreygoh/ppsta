<?php
$host = "localhost";
$user = "johnrey";  //"root"
$pass = "123";      //""
$db = "ppsta";

$mysqli = new mysqli($host,$user,$pass,$db);
if($mysqli->connect_error){
    die("Error:".$mysqli->error);
}
?>