<?php
if(isset($_GET['empid'])){

    $id = $_GET['empid'];
    require('connections/connection2.php');
    
    $stmt = $mysqli->prepare("CALL deleteemployee(?)");
    $stmt->bind_param("s",$id);
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
    
    header("LOCATION:showemployees.php");
}else{
    header("LOCATION:showemployees.php");
}
?>
