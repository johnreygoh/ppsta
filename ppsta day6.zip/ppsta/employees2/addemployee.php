<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Employee</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box" style="text-align: center;">

<h1 style="text-align:center;">Add New Employee</h1>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

<table class="table table-striped" style="width:40%;text-align:center;margin:auto;">
<tr>
    <td><label for="txt_fn">First Name</label></td>
    <td><input type="text" name="txt_fn" class="form-control" required></td>
</tr>
<tr>
    <td><label for="txt_ln">Last Name</label></td>
    <td><input type="text" name="txt_ln" class="form-control" required></td>
</tr>
<tr>
    <td><label for="txt_de">Department</label></td>
    <td><input type="text" name="txt_de" class="form-control" required></td>
</tr>
<tr>
    <td><label for="txt_po">Position</label></td>
    <td><input type="text" name="txt_po" class="form-control" required></td>
</tr>
<tr>
    <td><label for="txt_sa">Salary</label></td>
    <td><input type="number" name="txt_sa" class="form-control" required></td>
</tr>
<tr>
    <td></td>
    <td style="text-align:right;">
        <input type="submit" 
                name="btn_submit" 
                class="btn btn-primary" 
                value="Submit">
    </td>
</tr>

</table>

</form>

<?php
if(isset($_POST['btn_submit'])){

    $fn = trim($_POST['txt_fn']);
    $ln = trim($_POST['txt_ln']);
    $de = trim($_POST['txt_de']);
    $po = trim($_POST['txt_po']);
    $sa = trim($_POST['txt_sa']);

    require('connections/connection2.php');
    $stmt = $mysqli->prepare("CALL addemployee(?,?,?,?,?);");
    $stmt->bind_param("sssss",$fn,$ln,$de,$po,$sa);
    $stmt->execute();
    $stmt->close();
    $mysqli->close();
    echo "New Record Added <br />";
    echo "<a href='showemployees.php'>View Records</a> | 
            <a href='addemployee.php'>Add Another Record</a>";

}
?>

</div>



    
</body>
</html>