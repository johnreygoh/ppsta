<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employee</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box">

<?php 
// pass only ID->search records based on id->fetch values
// or pass all values in url, gets values from url, no db searching

if(isset($_GET['empid'])){
    $id = $_GET['empid'];

    require('connections/connection1.php');
    $searchsql = "select * from employees where empid=$id";
    $result = mysqli_query($con,$searchsql) or die(mysqli_error($con));
    if(mysqli_num_rows($result)>0){

        $row = mysqli_fetch_row($result);
        echo "
        
        <form method='post' action='editemployeeprocessing.php'>
        <h1>Edit Record</h1>

        <table class='table table-striped' style='width:40%;margin:auto;'>
        <tr>
            <td><label for='txt_id'>Employee ID</label></td>
            <td><input type='text' name='txt_id' value='$row[0]' readonly class='form-control'></td>
        </tr>
        <tr>
            <td><label for='txt_fn'>First Name</label></td>
            <td><input type='text' name='txt_fn' value='$row[1]' required class='form-control'></td>
        </tr>
        <tr>
            <td><label for='txt_ln'>Last Name</label></td>
            <td><input type='text' name='txt_ln' value='$row[2]' required class='form-control'></td>
        </tr>
        <tr>
            <td><label for='txt_de'>Department</label></td>
            <td><input type='text' name='txt_de' value='$row[3]' required class='form-control'></td>
        </tr>
        <tr>
            <td><label for='txt_po'>Position</label></td>
            <td><input type='text' name='txt_po' value='$row[4]' required class='form-control'></td>
        </tr>
        <tr>
            <td><label for='txt_sa'>Salary</label></td>
            <td><input type='number' name='txt_sa' value=$row[5] required class='form-control'></td>
        </tr>
        <tr>
            <td></td>
            <td style='text-align:right;'>
            <input type='submit' 
                name='btn_submit' 
                value='Update' 
                class='btn btn-success'>
            </td>
        </tr>

        </table>
        </form>
        ";

    }else{  
        //if no records found
        echo "No record(s) found.";
    }

    mysqli_close($con);

} // closing if(isset())

?>


</div>

    
</body>
</html>