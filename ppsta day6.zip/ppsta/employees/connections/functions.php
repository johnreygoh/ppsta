<?php
function updaterec($i,$f,$l,$d,$p,$s){

    $sql = "update employees set 
    firstname='$f', 
    lastname='$l', 
    department='$d', 
    position='$p', 
    salary=$s 
    where empid=$i           
    ";

    return $sql;

}
?>