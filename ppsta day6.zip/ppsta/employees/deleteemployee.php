<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Employee</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box">

<?php
if(isset($_GET['empid'])){

    $id = $_GET['empid'];
    require('connections/connection1.php');
    $sql = "delete from employees where empid=$id";
    mysqli_query($con,$sql) or die(mysqli_error($con));
    mysqli_close($con);
    header("LOCATION:showemployees.php");
}else{
    header("LOCATION:showemployees.php");
}
?>

</div>

    
</body>
</html>