<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee List</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>
<?php include("../navbar/navbar.php"); ?>

<div class="box">
<h1>Employees</h1>


<!-- search facility -->
<div style="text-align: right;">
<form method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
<select name="cbo_search">
    <option value="firstname">FIRST NAME</option>
    <option value="lastname">LAST NAME</option>
    <option value="department">DEPARTMENT</option>
</select>
<input type="text" name="txt_search">
<input type="submit" name="btn_search" value="search">
</div>

<br /><br />

<div style="text-align: right;">
<a href="logout.php">Logout</a> | <a href="addemployee.php">Add Record</a>
<br /><br />
</div>

<!-- show records -->
<?php 

if(!isset($_POST["btn_search"])){
    # btn not clicked
    # show all records
    require("connections/connection1.php"); 
    $sql = "select * from employees";
    $result = mysqli_query($con,$sql) or die("error:".mysqli_error($con));
    if(mysqli_num_rows($result)>0){
    
        echo "
        <table class='table table-striped table-hover'>
        <tr>
            <th>Employee ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Department</th>
            <th>Position</th>
            <th>Salary</th>
            <th></th>
        </tr>    
        ";
    
        while($row=mysqli_fetch_row($result)){
            echo "
            <tr>
                <td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
                <td>$row[4]</td>
                <td>PHP $row[5]</td>
                <td>
                <a href='editemployee.php?empid=$row[0]' 
                    onClick=\"return confirm('proceed to update record?');\">edit</a>
                
                &nbsp;&nbsp; | &nbsp;&nbsp;
                <a href='deleteemployee.php?empid=$row[0]' 
                    onClick=\"return confirm('sure to delete record?');\">delete</a>
    
                </td>    
            </tr>
            ";        
        }
    
        echo "</table><br />records found:".mysqli_num_rows($result);
    } //end if records found
    else
    {
        echo "No records found.";
    }
    
    mysqli_close($con);

}else{
    # btn clicked
    # search filtered results
    require("connections/connection1.php"); 
    $search_col = $_POST["cbo_search"];
    $search_txt = $_POST["txt_search"];
    $sql = "select * from employees where $search_col like '%$search_txt%'";
    
    $result = mysqli_query($con,$sql) or die("error:".mysqli_error($con));
    if(mysqli_num_rows($result)>0){
    
        echo "
        <table class='table table-striped table-hover'>
        <tr>
            <th>Employee ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Department</th>
            <th>Position</th>
            <th>Salary</th>
            <th></th>
        </tr>    
        ";
    
        while($row=mysqli_fetch_row($result)){
            echo "
            <tr>
                <td>$row[0]</td>
                <td>$row[1]</td>
                <td>$row[2]</td>
                <td>$row[3]</td>
                <td>$row[4]</td>
                <td>PHP $row[5]</td>
                <td>
                <a href='editemployee.php?empid=$row[0]' 
                    onClick=\"return confirm('proceed to update record?');\">edit</a>
                
                &nbsp;&nbsp; | &nbsp;&nbsp;
                <a href='deleteemployee.php?empid=$row[0]' 
                    onClick=\"return confirm('sure to delete record?');\">delete</a>
    
                </td>    
            </tr>
            ";        
        }
    
        echo "</table><br />records found:".mysqli_num_rows($result);
    } //end if records found
    else
    {
        echo "No records found.";
    }
    
    mysqli_close($con);




}
?>

</div>
   
</body>
</html>