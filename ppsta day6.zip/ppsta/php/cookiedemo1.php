<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cookie demo 1</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<?php 
    if(isset($_COOKIE["user"])){
        echo "Welcome ".$_COOKIE["user"];
    }else{
        echo "no more cookies";
    }
?>

<a href="cookiedemo1.php">cookie demo 1</a> | 
<a href="cookiedemo2.php">cookie demo 2</a> 


    
</body>
</html>