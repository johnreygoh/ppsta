<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>
<?php include("../myfunctions/functions_set1.php"); ?>

<div class="box">

<?php 
$w = " apple ";
echo "trimmed: ".trim($w)."<br />";
echo "characters: ".strlen(trim($w))."<br />";
echo "upper: ".strtoupper($w)."<br />";
echo "lower: ".strtolower($w)."<br />";
echo "word count: ".str_word_count($w)."<br />";
echo "compare case sensitive: ".strcmp(trim($w),"Apple")."<br />";
echo "compare case insensitive: ".strcasecmp(trim($w),"Apple")."<br />";
echo "first 3:".substr(trim($w),0,3)."<br />";
echo "last 3:".substr(trim($w),strlen(trim($w))-3,3)."<br />";


// basic input sanitation
$p = "<script type='text/javascript'>alert('you have been hacked');</script>";
// $p=trim($input);
// $p=htmlspecialchars($p);
// $p=stripslashes($p);
// $p=str_replace('/','',trim($p)); 
echo clean_input($p)."<br />";
echo getnetpay(80000,5000)."<br />";
echo $companyname."<br />";
$companyname="GMA";
echo $companyname."<br />";






?>


</div>




    
</body>
</html>