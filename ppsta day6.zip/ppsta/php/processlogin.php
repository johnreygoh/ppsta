<?php
session_start();

if(isset($_POST["btn_submit"])){
    $u = $_POST["txt_user"];
    $p = $_POST["txt_pass"];
    
    if($u=="admin" && $p=="123"){
        $_SESSION["user"]="admin";
        header("LOCATION:sample1.php");
    }else{
        header("LOCATION:accessdenied.php");
    }
}

?>