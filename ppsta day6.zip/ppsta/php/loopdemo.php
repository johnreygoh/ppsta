<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>loop demo</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<div class="box">
<h1>Loop Demo</h1>

<?php 
// do, while, for

// while
// variable that monitors iteration
// $count1 = 15;
// while($count1<=10){
//     echo "$count1. hi there<br />";
//     //$count1 = $count1 + 1;
//     $count1+=1;
//     //$count1++;
// }

// do-while
// $count1=1;
// do{
//     echo "$count1. hello<br />";
//     $count1++;
// }while($count1<=10);

// for
for($count1=1; $count1<=20; $count1+=1){
    echo "$count1. good am<br />";
}





?>

</div>

    
</body>
</html>