<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Upload</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>

<div class="box">
<h1>file upload</h1>

<form method="post" 
    enctype="multipart/form-data" 
    action="<?php echo $_SERVER['PHP_SELF']; ?>">

upload file <input type="file" name="file1"> <br />
<input type="submit" name="btn_submit" value="upload">
</form>

<?php 
if(isset($_POST["btn_submit"])){

    if($_FILES["file1"]["error"]==0){

        echo "file name:".$_FILES["file1"]["name"]."<br />";
        echo "file type:".$_FILES["file1"]["type"]."<br />";
        echo "file size:".($_FILES["file1"]["size"]/1024)." kb<br />";

        // selected file from your browser gets cached in tmp_name
        // move_uploaded_file(source,destination)
        move_uploaded_file($_FILES["file1"]["tmp_name"],"../uploads/".$_FILES["file1"]["name"]);

        echo "stored in uploads/".$_FILES["file1"]["name"];            
    }

}

?>





</div>


</body>
</html>
