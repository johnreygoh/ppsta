<?php
session_start();
if(!isset($_SESSION["user"])){
    header("LOCATION:accessdenied.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission</title>

    <link rel="stylesheet" href="../bootstrap/bootstrap.min.css">
    <script src="../bootstrap/jquery.min.js"></script>
    <script src="../bootstrap/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/phpstyle.css">

</head>
<body>

<?php include("../navbar/navbar.php"); ?>
<div class="box">

<h1>Schedule Request</h1>
<form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
first name <input type="text" name="txt_fn"><br />
last name <input type="text" name="txt_ln"><br />
department 
<select name="cbo_dept">
    <option value="MIS">MIS</option>
    <option value="HR">HR</option>
    <option value="Accounting">Accounting</option>
</select>
<br />
Preferred Schedule 
<input type="radio" name="rad_sched" value="am" checked>AM
<input type="radio" name="rad_sched" value="pm">PM

<br /><br />
<input type="submit" name="btnsubmit" value="submit">
</form>

<hr />

<div>
    <?php
    if(isset($_POST["btnsubmit"])){
        $f = $_POST["txt_fn"];
        $l = $_POST["txt_ln"];
        $d = $_POST["cbo_dept"];
        $s = $_POST["rad_sched"];
    
        echo "Good day $f $l! <br />You are requesting a $s in $d.<br /><br />";
    }else{
        echo "Please fill up the form";
    }
    
    ?>
</div>




</div>




    
</body>
</html>