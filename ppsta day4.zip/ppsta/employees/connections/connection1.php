<?php 
$host = "localhost";
$user = "johnrey";  //"root"
$pass = "123";      //""
$db = "ppsta";
//open connection
$con = mysqli_connect($host,$user,$pass,$db) or die("unable to connect");
//query
// $sql = "select * from employees";
//execute query
// $result = mysqli_query($con,$sql) or die("error:".mysqli_error($con));
//use the result
// print_r($result);
//close conenction
// mysqli_close($con);
?>